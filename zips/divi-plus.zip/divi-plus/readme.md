#	Divi Plus

Divi Plus is a multipurpose plugin for Divi.

##	Installation

For instructions on how to install the plugin, please visit https://diviextended.com/documentation/.

## Support

Please visit https://diviextended.com/support/ for support.